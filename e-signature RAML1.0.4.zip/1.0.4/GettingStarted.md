<ul>
	<li>API model and schema: <a href="https://code.td.com/plugins/servlet/archive/projects/APISPEC/repos/esignature?at=refs%2Fheads%2Fmaster" target="ESIGNATURE-ESIGNLIVE_raml">RAML and JSON files</a></li>
	<li>Offline documentation: <a href="javascript:window.location.assign('http://apispecsdrafts.tdbfg.com/esignatureevents/ESignLive/1.0.4/ESignLiveESignatureEvents%20API%20Reference%20-%20Draft.chm')">CHM file</a></li>
</ul>  
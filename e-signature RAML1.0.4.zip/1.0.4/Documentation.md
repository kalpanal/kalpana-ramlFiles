ESignature Events API (ESignLive) is used by Digitization & Automation to provide electronic signature service.

- electronic signature services:

```plantuml
@startuml 
actor Consumer
participant ESignature_Events_API 
participant ESignLive_Platform 

Consumer -> ESignature_Events_API : Add /esignatureevents
ESignature_Events_API  -> ESignLive_Platform: AddESignatureEventsRq
ESignLive_Platform --> ESignature_Events_API : Response
ESignature_Events_API --> Consumer: AddESignatureEventsRs

Consumer -> ESignature_Events_API : Get /esignatureevents/{eventId}
ESignature_Events_API  -> ESignLive_Platform: RetrieveESignatureEventsRq
ESignLive_Platform --> ESignature_Events_API : Response
ESignature_Events_API --> Consumer:RetrieveESignatureEventsRs
 
@enduml 
```

- multi-use session token:

```plantuml
@startuml 
actor Consumer
participant "PING Fed TD" 
participant ESignature_Events_API 
participant ESignLive_Platform 

Consumer -> "PING Fed TD": get Ping Fed oAuth token
"PING Fed TD" --> Consumer: response

Consumer -> ESignature_Events_API: generate multi-use session token
ESignature_Events_API -> ESignLive_Platform: generate multi-use session token
ESignLive_Platform --> ESignature_Events_API: response
ESignature_Events_API --> Consumer: response
Consumer -> Consumer: construct signer UI url

Consumer -> ESignLive_Platform: display signer UI as embedded within the LOB app
ESignLive_Platform --> Consumer: response

@enduml 
```
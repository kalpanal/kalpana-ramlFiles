<ul>
        <li>API model and schema: <a href="https://code.td.com/projects/APISPEC/repos/docapi/browse/KOFAX/1.0.0">RAML and JSON files</a></li>
        <li>Offline Documentation: <a href="javascript:window.location.assign('http://apispecs.tdbfg.com/Documents/KOFAX/1.0.0/KOFAXDocuments%20API%20Reference.chm')">CHM File</a></li>
      </ul>     
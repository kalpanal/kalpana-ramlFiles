Documents API (KOFAX) creates and monitors ingestion tasks that place an ingestion package on "KIC for Folder" with details provided in request.
 
```plantuml
@startuml
actor Client
boundary Documents_API 
participant KOFAX
alt 
Client -> Documents_API: POST /documents/ingestions
Documents_API -> KOFAX: multipart/form-data
else successful
KOFAX --> Documents_API: Response
Documents_API--> Client: AddDocumentIngestionRs + HTTP Status Code 202
else unsuccessful
KOFAX --> Documents_API: Response
Documents_API--> Client: status schema+http status 4xx, 5xx
else
@enduml 
```


- retrieve status of ingestion task by the original requestor:

```plantuml
@startuml
actor Client
boundary Documents_API 
participant KOFAX  

Client -> Documents_API: GET /documents/ingestions/{ingestionId}/status
Documents_API -> KOFAX: Request data
KOFAX --> Documents_API: Response
Documents_API--> Client: RetrieveDocumentIngestionStatusRs + HTTP Status Code 200
@enduml 
```